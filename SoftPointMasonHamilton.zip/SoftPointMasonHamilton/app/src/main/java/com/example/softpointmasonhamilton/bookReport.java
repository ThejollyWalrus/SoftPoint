package com.example.softpointmasonhamilton;

public class bookReport {

    private int id;
    private String bookAuthor;
    private String bookTitle;
    private String bookDescription;
    private String bookDatePublished;
    private int image;



    public bookReport(int id, String bookAuthor, String bookTitle, String bookDescription, String bookDatePublished, int image) {
        this.id = id;
        this.bookAuthor = bookAuthor;
        this.bookTitle = bookTitle;
        this.bookDescription = bookDescription;
        this.bookDatePublished = bookDatePublished;
        this.image = image;
    }

    public bookReport(){

    }


    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getBookDescription() {
        return bookDescription;
    }

    public void setBookDescription(String bookDescription) {
        this.bookDescription = bookDescription;
    }

    public String getBookDatePublished() {
        return bookDatePublished;
    }

    public void setBookDatePublished(String bookDatePublished) {
        this.bookDatePublished = bookDatePublished;
    }
}
