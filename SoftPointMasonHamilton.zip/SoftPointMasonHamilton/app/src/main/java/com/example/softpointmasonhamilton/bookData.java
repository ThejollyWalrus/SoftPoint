package com.example.softpointmasonhamilton;

import android.content.Context;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class bookData  {


    public static final String Website_Location = "https://softpointdev.com/sdk/api/v01/book_data.php";
    Context context;

    public bookData(Context context){
        this.context = context;
    }

    public interface CheckForBooks{
        void onError(String message);
        void onResponse(List<bookReport> bookReportList);
    }

    public void getData(CheckForBooks checkForBooks){




        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, Website_Location, null, new Response.Listener<JSONObject>() {



            List<com.example.softpointmasonhamilton.bookReport> totalBookReports = new ArrayList<>();


            @Override
            public void onResponse(JSONObject response) {
                Toast.makeText(context, "it worked", Toast.LENGTH_SHORT).show();


                try {

                    JSONArray bookList = response.getJSONArray("Books");

                    //for loop below to store all sep entries


                   // System.out.println("Size of data array"  + bookList.length());

                    for (int i =0; i<bookList.length(); i ++) {

                        com.example.softpointmasonhamilton.bookReport oneBook = new com.example.softpointmasonhamilton.bookReport();

                        JSONObject bookFromAPI = (JSONObject) bookList.get(i);
                        oneBook.setBookAuthor(bookFromAPI.getString("Author"));
                        oneBook.setBookTitle(bookFromAPI.getString("Title"));
                        oneBook.setBookDescription(bookFromAPI.getString("Description"));
                        oneBook.setBookDatePublished(bookFromAPI.getString("Published"));

                        totalBookReports.add(oneBook);
                    }

                    checkForBooks.onResponse(totalBookReports);




                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Didn't work", Toast.LENGTH_SHORT).show();
                System.out.println( "HERE5");
                checkForBooks.onError("Something Went Wrong");
            }
        });

        com.example.softpointmasonhamilton.MySingleton.getInstance(context).addToRequestQueue(request);




    }


}
