package com.example.softpointmasonhamilton;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Details extends AppCompatActivity {

    TextView bookTitle, bookAuth, bookDate, bookDesc;
    Button btn_back;
    int position =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        bookTitle = findViewById(R.id.tv_dTitle);
        bookAuth = findViewById(R.id.tv_dAuth);
        bookDate = findViewById(R.id.tv_dDate);
        bookDesc = findViewById(R.id.tv_dDescription);
        btn_back= findViewById(R.id.btn_back);

        Bundle incomingMsg = getIntent().getExtras();

        if(incomingMsg != null){
            bookDate.setText(incomingMsg.getString("date"));
            bookAuth.setText(incomingMsg.getString("theBook"));
            bookDesc.setText(incomingMsg.getString("desc"));
            bookTitle.setText(incomingMsg.getString("title"));
            position = incomingMsg.getInt("spot");


        }



        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home = new Intent(v.getContext(), MainActivity.class);

                home.putExtra("spot", position);

                startActivity(home);
            }
        });







    }
}