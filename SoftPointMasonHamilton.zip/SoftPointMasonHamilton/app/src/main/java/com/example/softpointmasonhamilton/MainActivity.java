package com.example.softpointmasonhamilton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.softpointmasonhamilton.db.DataBase;
import com.example.softpointmasonhamilton.db.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements RecyclerViewAdapter.ItemClickListener{

    TextView tv_author, tv_title, tv_description, tv_auth2;
    Button btn_next;
    public int location =0;
    private List<bookReport> reportOfBooks;
    private List<User> userList;
    RecyclerViewAdapter adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_title = findViewById(R.id.tv_title);
        tv_author = findViewById(R.id.tv_author);
        tv_description = findViewById(R.id.tv_description);

        tv_auth2 = findViewById(R.id.tv_auth2);

        reportOfBooks = new ArrayList<>();
        userList = new ArrayList<>();


        final bookData data = new bookData(this);

        bookReport one_display = new bookReport();

        DataBase db = DataBase.getDbInstance(MainActivity.this.getApplicationContext());

        userList  = db.userDao().getAllUsers();

        if(userList.size() >0){

            System.out.println("DB size: " +userList.size());


            //userList.get(0).lastName
            //db.userDao().deleteALL();


            RecyclerView recyclerView = findViewById(R.id.rv_view);
            recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
            adapter = new RecyclerViewAdapter(MainActivity.this, userList);
            adapter.setClickListener(MainActivity.this);
            //adapter.stateRestorationPolicy = RecyclerView.Adapter.StateRestorationPolicy.PREVENT_WHEN_EMPTY;
            adapter.setStateRestorationPolicy(RecyclerView.Adapter.StateRestorationPolicy.ALLOW);

            recyclerView.setAdapter(adapter);



            Bundle incomingMsg = getIntent().getExtras();
            if(incomingMsg != null) {
                location = incomingMsg.getInt("spot");
                recyclerView.scrollToPosition(location);
            }





        }


else {

            data.getData(new bookData.CheckForBooks() {
                @Override
                public void onError(String message) {
                    Toast.makeText(MainActivity.this, "Wrong part1", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onResponse(List<bookReport> bookReportList) {
                    //Toast.makeText(MainActivity.this, "Worked Main size:" + bookReportList.size(), Toast.LENGTH_SHORT).show();

                   // System.out.println("HERE Size: " + bookReportList.size());
                    for (int i = 0; i < bookReportList.size(); i++) {
                        bookReport one_book = bookReportList.get(i);

                        String author = one_book.getBookAuthor();
                        String tittle = one_book.getBookTitle();
                        String desc = one_book.getBookDescription();

                        tv_author.setText(author);
                        tv_title.setText(tittle);
                        tv_description.setText(desc);


                        Random random = new Random();

                        int picSpot = random.nextInt(17);

                        String thePic = "a" + picSpot;

                        int res = getResources().getIdentifier(thePic, "drawable", MainActivity.this.getPackageName());

                        one_book.setImage(res);

                        reportOfBooks.add(one_book);

                        DataBase db = DataBase.getDbInstance(MainActivity.this.getApplicationContext());

                        User user = new User();
                        user.dbTitle = one_book.getBookTitle();
                        user.dbAuthor = one_book.getBookAuthor();
                        user.dbDate = one_book.getBookDatePublished();
                        user.dbDesc = one_book.getBookDescription();
                        user.dbPic = res;

                        db.userDao().insertUser(user);
                        userList.add(user);


                    }
                    RecyclerView recyclerView = findViewById(R.id.rv_view);
                    recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                    adapter = new RecyclerViewAdapter(MainActivity.this, userList);
                    adapter.setClickListener(MainActivity.this);
                    recyclerView.setAdapter(adapter);


                }
            });

        }




    }



    @Override
    public void onItemClick(View view, int position) {

        tv_description.setText(adapter.getItem(position));

        Intent intent = new Intent(view.getContext(), Details.class);

        location = position;


        String name = userList.get(position).dbAuthor;
        String date = userList.get(position).dbDate;
        String desc = userList.get(position).dbDesc;
        String title = userList.get(position).dbTitle;

        intent.putExtra("theBook", name);
        intent.putExtra("date", date);
        intent.putExtra("title", title);
        intent.putExtra("desc", desc);
        intent.putExtra("spot", location);



        startActivity(intent);

        //Toast.makeText(MainActivity.this, "Clicked" + adapter.getItem(position), Toast.LENGTH_SHORT).show();
        //Toast.makeText(MainActivity.this, "Loac" + position, Toast.LENGTH_SHORT).show();
    }
}