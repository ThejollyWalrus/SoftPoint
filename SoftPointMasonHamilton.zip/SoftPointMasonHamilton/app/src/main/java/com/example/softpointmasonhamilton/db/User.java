package com.example.softpointmasonhamilton.db;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class User {

    @PrimaryKey(autoGenerate = true)
    public int uid;

    @ColumnInfo(name = "author")
    public  String dbAuthor;

    @ColumnInfo(name = "title")
    public  String dbTitle;

    @ColumnInfo(name = "date")
    public String dbDate;

    @ColumnInfo(name = "desc")
    public String dbDesc;

    @ColumnInfo(name = "picId")
    public int dbPic;




}
